import React, { useState } from "react";
import axios from "axios";
import { saveAs } from "file-saver";
import "./genimation.css";

const API_KEY = process.env.REACT_APP_REPLICATE_API_KEY
console.log(API_KEY)
const Genimation = () => {
  const [input, setInput] = useState("");
  const [videoUrl, setVideoUrl] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!input) {
      alert("Please enter a description!");
      return;
    }

    setLoading(true);

    try {
      // Step 1: Start video generation using Replicate API
      const response = await axios.post(
        "https://api.replicate.com/v1/predictions",
        {
          model: "haiper-ai/haiper-video-2",
          // version: "3e963e6a0e1631535e57bc8401292cd94996dc12152a37b499229e70155601e7",  // Haiper-Video-2 model version ID
          input: { prompt: input, duration: 4 },
        },
        {
          headers: {
            Authorization: `Token ${API_KEY}`,
            "Content-Type": "application/json",
          },
        }
      );

      const predictionId = response.data.id;
      console.log(predictionId)

      // Step 2: Poll the API until video is ready
      let status = response.data.status;
      let video = null;

      while (status !== "succeeded" && status !== "failed") {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait 5 sec before checking status

        const result = await axios.get(`https://api.replicate.com/v1/predictions/${predictionId}`, {
          headers: {
            Authorization: `Token ${process.env.REACT_APP_REPLICATE_API_KEY}`,
          },
        });

        status = result.data.status;
        video = result.data.output;
      }

      if (status === "succeeded" && video) {
        setVideoUrl(video); // Set video URL
      } else {
        alert("Video generation failed.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to generate video.");
    }

    setLoading(false);
  };

  const handleDownload = () => {
    if (videoUrl) {
      fetch(videoUrl)
        .then((response) => response.blob())
        .then((blob) => {
          saveAs(blob, "generated-video.mp4");
        })
        .catch((error) => {
          console.error("Error downloading video:", error);
          alert("Failed to download.");
        });
    } else {
      alert("No video available.");
    }
  };

  return (
    <section className="dynamic-component">
      <div className="icon">
        {videoUrl ? (
          <div className="output-section">
            <video src={videoUrl} controls></video>
            <button className="button download" onClick={handleDownload}>
              Download Video
            </button>
          </div>
        ) : (
          <i className="bx bxs-video"></i>
        )}
      </div>
      <div className="input-section genimation">
        <input
          type="text"
          className="prompt"
          placeholder="Describe your idea..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button className="button generate" onClick={handleGenerate} disabled={loading}>
          {loading ? "Generating..." : "Generate!"}
        </button>
      </div>
    </section>
  );
};

export default Genimation;

// import React, { useState } from "react";
// import "./genimation.css";
// import { saveAs } from 'file-saver';

// const Genimation = () => {
//   const [input, setInput] = useState("");
//   const [videoUrl, setVideoUrl] = useState(null);
//   const [loading, setLoading] = useState(false);

//   const handleGenerate = async () => {
//     if (!input) {
//       alert("Please enter a description!");
//       return;
//     }

//     setLoading(true);
//     try {
//       const response = await fetch(`${process.env.REACT_APP_API_URL}/generate-video`, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ prompt: input }),
//       });

//       const data = await response.json();

//       if (data.video_url) {
//         setVideoUrl(data.video_url);  // Set the video URL returned from backend
//       } else {
//         alert("Error generating video.");
//       }
//     } catch (error) {
//       console.error("Error:", error);
//       alert("Failed to connect to server.");
//     }
//     setLoading(false);
//   };
 
//   const handleDownload = () => {
//     if (videoUrl) {
//       // Fetch the video file as a Blob
//       fetch(videoUrl)
//         .then(response => response.blob())  // Convert the response to a Blob
//         .then(blob => {
//           // Trigger the download using file-saver
//           saveAs(blob, videoUrl.split('/').pop());  // Use the file name from the URL
//         })
//         .catch(error => {
//           console.error('Error downloading the video:', error);
//           alert('Failed to download the video.');
//         });
//     } else {
//       alert('Video not ready for download.');
//     }
//   };
  

//   return (
//     <section className="dynamic-component">
//       <div className="icon">
//         {videoUrl ? (
//           <div className="output-section">
//             <video src={videoUrl} controls></video>
//             <button className="button download" onClick={handleDownload}>
//               Download Video
//             </button>
//           </div>
//         ) : (
//           <i className="bx bxs-video"></i>
//         )}
//       </div>
//       <div className="input-section genimation">
//         <input
//           type="text"
//           className="prompt"
//           placeholder="Describe your idea..."
//           value={input}
//           onChange={(e) => setInput(e.target.value)}
//         />
//         <button className="button generate" onClick={handleGenerate} disabled={loading}>
//           {loading ? "Generating..." : "Generate!"}
//         </button>
//       </div>
//     </section>
//   );
// };

// export default Genimation;
